﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows;
using ExcelDataReader;
using Microsoft;
using XL = Microsoft.Office.Interop.Excel;
//TO-DO:
//Insertion: Houston: Pretty Much Complete
//Deletion: Prince
//Alteration: Austin
//Color problem with ordering: Complete
//Fields problem with ordering: Complete
//Multiple GPAs in the CadetTab: Houston
//Alter table according to Jungs specs
namespace WindowsFormsApp2
{
    public partial class CadetWatch : Form
    {
        public CadetWatch()
        {
            InitializeComponent();
        }
        DataSet result = new DataSet();
        String path = @"G:\OO Project\Project\gCadets.xlsx";//String path of the excel sheet
        String tempPath = @"G:\OO Project\Project\tempCadets.xlsx";
        private void CadetWatch_Load(object sender, EventArgs e)
        {
            Boolean t = true;
            Boolean f = false;
            CadetView.ReadOnly = t;   //Sets the datagrid to be non-editable
            CadetView.AllowUserToAddRows = f;
            //String path of the excel sheet
            FileStream fs = File.OpenRead(path);   //a file stream that opens the file
            IExcelDataReader reader = ExcelReaderFactory.CreateOpenXmlReader(fs);
            result = reader.AsDataSet(new ExcelDataSetConfiguration()
            {
                ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                {
                    UseHeaderRow = true
                }
            });// This whole thing is setting the first table in dataset 'result' to be the excel table, it also sets the headers to be the values of the first row
            CadetView.DataSource = result.Tables[0];
            for (int i = 0; i < CadetView.ColumnCount; i++)
            {
                CadetView.Columns[i].Visible = f;
            }
            //Sets only pertinent columns to visible
            CadetView.Columns["First Name"].Visible = t;
            CadetView.Columns["Last Name"].Visible = t;
            CadetView.Columns["MS Level"].Visible = t;
            CadetView.Columns["Major"].Visible = t;
            CadetView.Columns["Eagle ID"].Visible = t;

            
            searchBox.KeyDown += new KeyEventHandler(searchEnter);//Adds a key event handler for enter to the searchBox
            CadetView.CellFormatting += new DataGridViewCellFormattingEventHandler(CadetViewRed);//Adds an event handler for cell formatting to keep BackColor through sorting
            tabView.TabPages.Remove(testTab);
            createTemp();
            fs.Close();
        }

        //This is a method to populate form 2 with information based on the cell you double-click on
        
        private void CadetView_CellDoubleClick(Object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex < 0)
            {
                return;
            }
            DataGridViewRow rows = CadetView.Rows[e.RowIndex];
            newTab(rows);
            //The following line is obsolete
            //Form2 form2 = new Form2(rows, e.RowIndex);
        }
        //This method is to search the table based on what is in searchBox
        private void searchBtn_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(searchBox.Text)) {
                for (int i = 0; i < CadetView.RowCount; i++)
                {
                    CurrencyManager m1 = (CurrencyManager)BindingContext[CadetView.DataSource];
                    m1.SuspendBinding();
                    String fSer = CadetView.Rows[i].Cells["First Name"].Value.ToString();
                    String lSer = CadetView.Rows[i].Cells["Last Name"].Value.ToString();
                    String[] find = {fSer, lSer };
                    String ser = fSer + lSer;
                    if (!ser.Contains(searchBox.Text))// && find[0] != searchBox.Text && find[1] != searchBox.Text)
                    {
                        CadetView.Rows[i].Visible = false;   
                    }
                    if(ser.Contains(searchBox.Text))//||find[0] == searchBox.Text||find[1] == searchBox.Text)
                    {
                        
                        CadetView.Rows[i].Visible = true;
                    }
                    m1.ResumeBinding();
                }
            }
        }
        //This method is for the refresh button, it refreshes the table
        private void refreshBtn_Click(object sender, EventArgs e)
        {
            refresh();
        }
        //This is the same method as searchBtn_Click, except it is called when you hit the 'Enter' key while in searchBox
        private void searchEnter(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter) {
                if (!String.IsNullOrEmpty(searchBox.Text))
                {
                    for (int i = 0; i < CadetView.RowCount; i++)
                    {
                        CurrencyManager m1 = (CurrencyManager)BindingContext[CadetView.DataSource];
                        m1.SuspendBinding();
                        String fSer = CadetView.Rows[i].Cells["First Name"].Value.ToString();
                        String lSer = CadetView.Rows[i].Cells["Last Name"].Value.ToString();
                        String[] find = { fSer, lSer };
                        String ser = fSer + lSer;
                        if (!ser.Contains(searchBox.Text))// && find[0] != searchBox.Text && find[1] != searchBox.Text)
                        {
                            CadetView.Rows[i].Visible = false;
                        }
                        if (ser.Contains(searchBox.Text))//||find[0] == searchBox.Text||find[1] == searchBox.Text)
                        {

                            CadetView.Rows[i].Visible = true;
                        }
                        m1.ResumeBinding();
                    }
                }
            }
        }
        //This method is called by the new cadet button to open and add cadet page
        public void newTab()
        {
            addCadet newCadet = new addCadet();
            newCadet.addPerson += (s, e) => AddCadet(newCadet);
            newCadet.addPicture += (s, e) => AddPicture(newCadet);
            TabPage uTab = new TabPage();
            uTab.Controls.Add(newCadet);//This adds the newCadet controls to the uTab
            uTab.Text = "New Cadet";
            tabView.TabPages.Add(uTab);
            tabView.SelectedTab = uTab;
        }
        //This method is an overloaded method that creates a tab based on the row clicked and the userControl CadetTab
        public void newTab(DataGridViewRow row)
        {
            CadetTab newCadet = new CadetTab(row);
            newCadet.editPerson += (s, e) => editCadet(newCadet);
            TabPage uTab = new TabPage();
            uTab.Controls.Add(newCadet);//This adds the newCadet controls to the uTab
            uTab.Text = row.Cells["First Name"].Value.ToString() + row.Cells["Last Name"].Value.ToString();
            tabView.TabPages.Add(uTab);
            tabView.SelectedTab = uTab;
        }
        //Closes the current tab, excluding the table tab
        private void closeBtn_Click(object sender, EventArgs e)
        {
            int i = tabView.SelectedIndex;
            if (tabView.SelectedTab.Text != "Cadet Table")
            {
                tabView.TabPages.Remove(tabView.SelectedTab);
                tabView.SelectedIndex = i - 1;
            }
        }
        //Method to ensure that rows with lower than 2.0 GPA remain red after sorting, called by the load
        private void CadetViewRed(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (CadetView.Rows[e.RowIndex].Cells["Term GPA"].Value.ToString() != "") {
                if ((double)CadetView.Rows[e.RowIndex].Cells["Term GPA"].Value < 2.0)
                {
                    DataGridViewRow row = CadetView.Rows[e.RowIndex];
                    row.DefaultCellStyle.BackColor = Color.Red;
                }
            }
        }
        //A test method to see if writing to an excel sheet is possible, contains basis for sheet alteration.
        //Garbage collection of the variables in the testInsert_Click method
        private void Cleanup()
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        private void newCadet_Click(object sender, EventArgs e)
        {
            newTab();
        }
        public void AddCadet(addCadet n)
        {
            if (n.fNameText() == "" || n.lNameText() == "" || n.idText() == "" 
                || n.msText() == "" || n.majorText() == "" || n.DoBText() == "" || n.nurseText() == "" 
                || n.msDateRet() == "" || n.csText() == "" || n.ptScoreText() == "" || n.ptDateText() == "" 
                || n.cumulativeText() == "" || n.termText() == "" || n.smpText() == "" || n.g2gText() == "" 
                || n.gradStatText() == "" || n.minorText() == "" || n.dodText() == "" || n.enrollText() == "")
            {
                MessageBox.Show("Invalid entry in one or more fields. Please make sure all fields are correct.");
                return;
            }
            XL.Application excel = new XL.Application();
            excel.DisplayAlerts = false;
            XL.Workbooks wbs = excel.Workbooks;
            XL.Workbook wb = wbs.Open(tempPath, ReadOnly: false, Editable: true);
            XL.Sheets wSheets = wb.Worksheets;
            XL.Worksheet ws = wSheets.Item[1] as XL.Worksheet;
            if (ws == null)
            {
                return;
            }
            int i =CadetView.Rows.Count;
            int empty = 0;
            XL.Range firstName = ws.Rows.Cells[i + 2, 1];
            XL.Range lastName = ws.Rows.Cells[i + 2, 2];
            XL.Range DoB = ws.Rows.Cells[i + 2, 3];
            XL.Range EagleID = ws.Rows.Cells[i + 2, 4];
            XL.Range msProjection = ws.Rows.Cells[i + 2, 5];
            XL.Range msLevel = ws.Rows.Cells[i + 2, 6];
            XL.Range contract = ws.Rows.Cells[i + 2, 7];
            XL.Range ptScore = ws.Rows.Cells[i + 2, 8];
            XL.Range ptDate = ws.Rows.Cells[i + 2, 9];
            XL.Range cumGPA = ws.Rows.Cells[i + 2, 10];
            XL.Range termGPA = ws.Rows.Cells[i + 2, 11];
            XL.Range SMP = ws.Rows.Cells[i + 2, 12];
            XL.Range G2G = ws.Rows.Cells[i + 2, 13];
            XL.Range gradStat = ws.Rows.Cells[i + 2, 14];
            XL.Range major = ws.Rows.Cells[i + 2, 15];
            XL.Range minor = ws.Rows.Cells[i + 2, 16];
            XL.Range dod = ws.Rows.Cells[i + 2, 17];
            XL.Range enrollment = ws.Rows.Cells[i + 2, 18];
            XL.Range nursing = ws.Rows.Cells[i + 2, 19];
            XL.Range picture = ws.Rows.Cells[i + 2, 20];

            firstName.Value = n.fNameText();
            lastName.Value = n.lNameText();
            EagleID.Value = n.idText();
            msLevel.Value = n.msText();
            major.Value = n.majorText();
            DoB.Value = n.DoBText();
            msProjection.Value = n.msDateRet();
            contract.Value = n.csText();
            ptScore.Value = n.ptScoreText();
            ptDate.Value = n.ptDateText();
            cumGPA.Value = n.cumulativeText();
            termGPA.Value = n.termText();
            SMP.Value = n.smpText();
            G2G.Value = n.g2gText();
            gradStat.Value = n.gradStatText();
            minor.Value = n.minorText();
            dod.Value = n.dodText();
            enrollment.Value = n.enrollText();
            nursing.Value = n.nurseText();
            if (n.picturePath() != "")
            {
                picture.Value = n.picturePath();
            }
            
            
            Cleanup();
            excel.Application.ActiveWorkbook.SaveAs(tempPath);
            excel.Application.Quit();
            excel.DisplayAlerts = true;
            excel.Quit();
            System.Threading.Thread.Sleep(15);
            refresh();
            
        }
        public void editCadet(CadetTab n)
        {
            if (n.fNameText() == "" || n.lNameText() == "" || n.idText() == ""
                || n.msText() == "" || n.majorText() == "" || n.DoBText() == "" || n.nurseText() == ""
                || n.msDateRet() == "" || n.csText() == "" || n.ptScoreText() == "" || n.ptDateText() == ""
                || n.cumulativeText() == "" || n.termText() == "" || n.smpText() == "" || n.g2gText() == ""
                || n.gradStatText() == "" || n.minorText() == "" || n.dodText() == "" || n.enrollText() == "")
            {
                MessageBox.Show("Invalid entry in one or more fields. Please make sure all fields are correct.");
                return;
            }
            XL.Application excel = new XL.Application();
            excel.DisplayAlerts = false;
            XL.Workbooks wbs = excel.Workbooks;
            XL.Workbook wb = wbs.Open(tempPath, ReadOnly: false, Editable: true);
            XL.Sheets wSheets = wb.Worksheets;
            XL.Worksheet ws = wSheets.Item[1] as XL.Worksheet;
            if (ws == null)
            {
                return;
            }
            string id = n.idText();
            int i = 0;
            for (int x = 1; x < CadetView.RowCount + 2; x++)
            {
                Console.WriteLine("{0}", x);
                XL.Range range = ws.Rows.Cells[x, 4];
                String cellID = range.Value.ToString();
                if (Equals(cellID, id))
                {
                    i = x;
                }
            }
            XL.Range firstName = ws.Rows.Cells[i, 1];
            XL.Range lastName = ws.Rows.Cells[i, 2];
            XL.Range DoB = ws.Rows.Cells[i, 3];
            XL.Range EagleID = ws.Rows.Cells[i, 4];
            XL.Range msProjection = ws.Rows.Cells[i, 5];
            XL.Range msLevel = ws.Rows.Cells[i, 6];
            XL.Range contract = ws.Rows.Cells[i, 7];
            XL.Range ptScore = ws.Rows.Cells[i, 8];
            XL.Range ptDate = ws.Rows.Cells[i, 9];
            XL.Range cumGPA = ws.Rows.Cells[i, 10];
            XL.Range termGPA = ws.Rows.Cells[i, 11];
            XL.Range SMP = ws.Rows.Cells[i, 12];
            XL.Range G2G = ws.Rows.Cells[i, 13];
            XL.Range gradStat = ws.Rows.Cells[i, 14];
            XL.Range major = ws.Rows.Cells[i, 15];
            XL.Range minor = ws.Rows.Cells[i, 16];
            XL.Range dod = ws.Rows.Cells[i, 17];
            XL.Range enrollment = ws.Rows.Cells[i, 18];
            XL.Range nursing = ws.Rows.Cells[i, 19];

            firstName.Value = n.fNameText();
            lastName.Value = n.lNameText();
            EagleID.Value = n.idText();
            msLevel.Value = n.msText();
            major.Value = n.majorText();
            DoB.Value = n.DoBText();
            msProjection.Value = n.msDateRet();
            contract.Value = n.csText();
            ptScore.Value = n.ptScoreText();
            ptDate.Value = n.ptDateText();
            cumGPA.Value = n.cumulativeText();
            termGPA.Value = n.termText();
            SMP.Value = n.smpText();
            G2G.Value = n.g2gText();
            gradStat.Value = n.gradStatText();
            minor.Value = n.minorText();
            dod.Value = n.dodText();
            enrollment.Value = n.enrollText();
            nursing.Value = n.nurseText();

           
            Cleanup();
            excel.Application.ActiveWorkbook.SaveAs(tempPath);
            excel.Application.Quit();
            excel.DisplayAlerts = true;
            excel.Quit();
            System.Threading.Thread.Sleep(15);
            refresh();
            
        }
        public void refresh()
        {
            Boolean t = true;
            Boolean f = false;
            CadetView.ReadOnly = t;   //Sets the datagrid to be non-editable
            CadetView.AllowUserToAddRows = f;
            FileStream fs = File.OpenRead(tempPath);   //a file stream that opens the file
            IExcelDataReader reader = ExcelReaderFactory.CreateOpenXmlReader(fs);
            result = reader.AsDataSet(new ExcelDataSetConfiguration()
            {
                ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                {
                    UseHeaderRow = true
                }
            });// This whole thing is setting the first table in dataset 'result' to be the excel table, it also sets the headers to be the values of the first row
            CadetView.DataSource = result.Tables[0];
            CadetView.Columns["Photo"].Visible = f; //Sets photo column to non-visible, it will be a file path and therefore ugly
            CadetView.CellFormatting += new DataGridViewCellFormattingEventHandler(CadetViewRed);//Adds an event handler for cell formatting to keep BackColor through sorting
            tabView.TabPages.Remove(testTab);
            fs.Close();
            searchBox.Text = "";
        }

        private void deleteBtn_Click(object sender, EventArgs e)
        {
            var dialog = MessageBox.Show("Are you sure?", "Confirm Delete", MessageBoxButtons.YesNo);

            if (dialog == DialogResult.Yes)
            {
                if (CadetView.CurrentCell == null || CadetView.CurrentCell.RowIndex < 0)
                {
                    return;
                }
                XL.Application excel = new XL.Application();
                excel.DisplayAlerts = false;
                XL.Workbooks wbs = excel.Workbooks;
                XL.Workbook wb = wbs.Open(path, ReadOnly: false, Editable: true);
                XL.Sheets wSheets = wb.Worksheets;
                XL.Worksheet ws = wSheets.Item[1] as XL.Worksheet;
                DataGridViewRow row = CadetView.Rows[CadetView.CurrentCell.RowIndex];
                String id = row.Cells["Eagle ID"].Value.ToString();
                try
                {
                    for (int i = 1; i < CadetView.RowCount + 2; i++)
                    {
                        Console.WriteLine("{0}", i);
                        XL.Range range = ws.Rows.Cells[i, 4];
                        String cellID = range.Value.ToString();
                        if (Equals(cellID, id))
                        {
                            range.EntireRow.Delete(XL.XlDeleteShiftDirection.xlShiftUp);
                        }
                    }
                }
                catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException)
                {
                    excel.Application.Quit();
                    excel.Quit();
                    Console.WriteLine("FAILURE");
                    return;
                }
                Cleanup();
                excel.Application.ActiveWorkbook.SaveAs(tempPath);
                excel.Application.Quit();
                excel.Quit();
                excel.DisplayAlerts = true;
                System.Threading.Thread.Sleep(15);
                refresh();
            }
            else
            {

            }
        }
        private void createTemp()
        {
            XL.Application excel = new XL.Application();
            excel.DisplayAlerts = false;
            XL.Workbooks wbs = excel.Workbooks;
            XL.Workbook wb = wbs.Open(path, ReadOnly: false, Editable: true);
            excel.Application.ActiveWorkbook.SaveAs(tempPath);
            excel.Application.Quit();
            excel.DisplayAlerts = true;
            excel.Quit();
        }

        private void saveBtn_Click(object sender, EventArgs e)
        {
            saveTemp();
        }
        private void saveTemp()
        {
            XL.Application excel = new XL.Application();
            excel.DisplayAlerts = false;
            XL.Workbooks wbs = excel.Workbooks;
            XL.Workbook wb = wbs.Open(tempPath, ReadOnly: false, Editable: true);
            excel.Application.ActiveWorkbook.SaveAs(path);
            excel.Application.Quit();
            excel.DisplayAlerts = true;
            excel.Quit();
        }
        public void AddPicture(addCadet n)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files|*.jpg;*.jpeg;*.png|All Files|*.*";
            openFileDialog.Title = "Find Cadet Picture";
            openFileDialog.ShowDialog();

            //Check to see if a filename was given
            if (openFileDialog.FileName != "")
            {
                string a = openFileDialog.FileName;
                n.setPicture(a);
            }
        }
    }
    
}
