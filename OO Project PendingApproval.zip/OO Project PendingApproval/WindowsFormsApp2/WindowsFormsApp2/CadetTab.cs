﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class CadetTab : UserControl
    {
        public delegate void ButtonClickedEventHandler(object sender, EventArgs e);
        public event ButtonClickedEventHandler editPerson;
        public CadetTab()
        {
            InitializeComponent();
        }
        private void ButtonClick(object sender, EventArgs e)
        {
            if (editPerson != null)
            {
                editPerson(this, e);
            }
        }
        public CadetTab(DataGridViewRow rows)
        {
            InitializeComponent();
            editBtn.Click += new EventHandler(ButtonClick);
            firstBox.Text = rows.Cells["First Name"].Value.ToString();
            lastBox.Text = rows.Cells["Last Name"].Value.ToString();
            IDBox.Text = rows.Cells["Eagle ID"].Value.ToString();
            dobPicker.Text = rows.Cells["Date of Birth"].Value.ToString();
            msDate.Text = rows.Cells["Mission Set Projection"].Value.ToString();
            msBox.Text = rows.Cells["MS Level"].Value.ToString();
            majorBox.Text = rows.Cells["Major"].Value.ToString();
            minorBx.Text = rows.Cells["Minor"].Value.ToString();
            contractBx.Text = rows.Cells["Contract Status"].Value.ToString();
            ptDateBx.Text = rows.Cells["PT Date"].Value.ToString();
            ptScoreBx.Text = rows.Cells["PT Score"].Value.ToString();
            majorBox.Text = rows.Cells["Major"].Value.ToString();
            cumilitiveBx.Text = rows.Cells["Cum. GPA"].Value.ToString();
            termBx.Text = rows.Cells["Term GPA"].Value.ToString();
            smpBx.Text = rows.Cells["SMP"].Value.ToString();
            g2gBx.Text = rows.Cells["G2G"].Value.ToString();
            gradBx.Text = rows.Cells["Grad Student"].Value.ToString();
            dodBx.Text = rows.Cells["DODMERB"].Value.ToString();
            enrollBx.Text = rows.Cells["Enrollment Paperwork"].Value.ToString();
            nurseBox.Text = rows.Cells["Nursing"].Value.ToString();
            String path = rows.Cells["Photo"].Value.ToString();
            try
            {
                studentImage.Image = Image.FromFile(@path);
            }
            catch (System.IO.FileNotFoundException)
            {
                studentImage.Image = Image.FromFile(@"G:\OO Project\Project\Pictures\errorImageResize.png");
            }
            catch (System.ArgumentException)
            {
                studentImage.Image = Image.FromFile(@"G:\OO Project\Project\Pictures\errorImageResize.png");
            }

        }

        public String fNameText()
        {
            return firstBox.Text;
        }
        public String lNameText()
        {
            return lastBox.Text;
        }
        public String idText()
        {
            return IDBox.Text;
        }
        public String msText()
        {
            return msBox.Text;
        }
        public String majorText()
        {
            return majorBox.Text;
        }
        public String msDateRet()
        {
            return msDate.Text;
        }
        public String DoBText()
        {
            return dobPicker.Text;
        }
        public String minorText()
        {
            return minorBx.Text;
        }
        public String csText()
        {
            return contractBx.Text;
        }
        public String ptDateText()
        {
            return ptDateBx.Text;
        }
        public String ptScoreText()
        {
            return ptScoreBx.Text;
        }
        public String cumulativeText()
        {
            return cumilitiveBx.Text;
        }
        public String termText()
        {
            return termBx.Text;
        }
        public String smpText()
        {
            return smpBx.Text;
        }
        public String g2gText()
        {
            return g2gBx.Text;
        }
        public String gradStatText()
        {
            return gradBx.Text;
        }
        public String dodText()
        {
            return dodBx.Text;
        }
        public String enrollText()
        {
            return enrollBx.Text;
        }
        public String nurseText()
        {
            return nurseBox.Text;
        }
        
    }
}
