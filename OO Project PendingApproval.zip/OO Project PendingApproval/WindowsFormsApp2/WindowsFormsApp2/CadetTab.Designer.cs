﻿namespace WindowsFormsApp2
{
    partial class CadetTab
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.studentImage = new System.Windows.Forms.PictureBox();
            this.nurseBox = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.enrollBx = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.dodBx = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.minorBx = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.gradBx = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.g2gBx = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.smpBx = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.termBx = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.cumilitiveBx = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ptScoreBx = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.contractBx = new System.Windows.Forms.TextBox();
            this.dobPicker = new System.Windows.Forms.DateTimePicker();
            this.msDate = new System.Windows.Forms.DateTimePicker();
            this.lastLbl = new System.Windows.Forms.Label();
            this.lastBox = new System.Windows.Forms.TextBox();
            this.majorLbl = new System.Windows.Forms.Label();
            this.majorBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.msBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.IDBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.firstBox = new System.Windows.Forms.TextBox();
            this.ptDateBx = new System.Windows.Forms.DateTimePicker();
            this.editBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.studentImage)).BeginInit();
            this.SuspendLayout();
            // 
            // studentImage
            // 
            this.studentImage.Location = new System.Drawing.Point(623, 30);
            this.studentImage.Name = "studentImage";
            this.studentImage.Size = new System.Drawing.Size(220, 236);
            this.studentImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.studentImage.TabIndex = 32;
            this.studentImage.TabStop = false;
            // 
            // nurseBox
            // 
            this.nurseBox.FormattingEnabled = true;
            this.nurseBox.Location = new System.Drawing.Point(257, 341);
            this.nurseBox.Name = "nurseBox";
            this.nurseBox.Size = new System.Drawing.Size(111, 21);
            this.nurseBox.TabIndex = 111;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(254, 325);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(89, 13);
            this.label17.TabIndex = 110;
            this.label17.Text = "Nursing Student?";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(254, 286);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(111, 13);
            this.label16.TabIndex = 109;
            this.label16.Text = "Enrolment Paperwork:";
            // 
            // enrollBx
            // 
            this.enrollBx.Location = new System.Drawing.Point(257, 302);
            this.enrollBx.Name = "enrollBx";
            this.enrollBx.Size = new System.Drawing.Size(111, 20);
            this.enrollBx.TabIndex = 108;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(254, 248);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 13);
            this.label15.TabIndex = 107;
            this.label15.Text = "DODMERB:";
            // 
            // dodBx
            // 
            this.dodBx.Location = new System.Drawing.Point(257, 264);
            this.dodBx.Name = "dodBx";
            this.dodBx.Size = new System.Drawing.Size(111, 20);
            this.dodBx.TabIndex = 106;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(36, 286);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(36, 13);
            this.label14.TabIndex = 105;
            this.label14.Text = "Minor:";
            // 
            // minorBx
            // 
            this.minorBx.Location = new System.Drawing.Point(39, 302);
            this.minorBx.Name = "minorBx";
            this.minorBx.Size = new System.Drawing.Size(111, 20);
            this.minorBx.TabIndex = 104;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(254, 209);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 13);
            this.label13.TabIndex = 103;
            this.label13.Text = "Grad Status:";
            // 
            // gradBx
            // 
            this.gradBx.Location = new System.Drawing.Point(257, 225);
            this.gradBx.Name = "gradBx";
            this.gradBx.Size = new System.Drawing.Size(111, 20);
            this.gradBx.TabIndex = 102;
            // 
            // label12
            // 
            this.label12.AutoEllipsis = true;
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(254, 170);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(29, 13);
            this.label12.TabIndex = 101;
            this.label12.Text = "G2G";
            // 
            // g2gBx
            // 
            this.g2gBx.Location = new System.Drawing.Point(257, 186);
            this.g2gBx.Name = "g2gBx";
            this.g2gBx.Size = new System.Drawing.Size(111, 20);
            this.g2gBx.TabIndex = 100;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(254, 131);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(33, 13);
            this.label11.TabIndex = 99;
            this.label11.Text = "SMP:";
            // 
            // smpBx
            // 
            this.smpBx.Location = new System.Drawing.Point(257, 147);
            this.smpBx.Name = "smpBx";
            this.smpBx.Size = new System.Drawing.Size(111, 20);
            this.smpBx.TabIndex = 98;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(254, 92);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 13);
            this.label10.TabIndex = 97;
            this.label10.Text = "Term GPA:";
            // 
            // termBx
            // 
            this.termBx.Location = new System.Drawing.Point(257, 108);
            this.termBx.Name = "termBx";
            this.termBx.Size = new System.Drawing.Size(111, 20);
            this.termBx.TabIndex = 96;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(254, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 13);
            this.label9.TabIndex = 95;
            this.label9.Text = "Cumilitive GPA:";
            // 
            // cumilitiveBx
            // 
            this.cumilitiveBx.Location = new System.Drawing.Point(257, 69);
            this.cumilitiveBx.Name = "cumilitiveBx";
            this.cumilitiveBx.Size = new System.Drawing.Size(111, 20);
            this.cumilitiveBx.TabIndex = 94;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(254, 14);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 93;
            this.label8.Text = "PT Score:";
            // 
            // ptScoreBx
            // 
            this.ptScoreBx.Location = new System.Drawing.Point(257, 30);
            this.ptScoreBx.Name = "ptScoreBx";
            this.ptScoreBx.Size = new System.Drawing.Size(111, 20);
            this.ptScoreBx.TabIndex = 92;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(36, 364);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 13);
            this.label7.TabIndex = 91;
            this.label7.Text = "PT Date:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(36, 325);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(83, 13);
            this.label6.TabIndex = 89;
            this.label6.Text = "Contract Status:";
            // 
            // contractBx
            // 
            this.contractBx.Location = new System.Drawing.Point(39, 341);
            this.contractBx.Name = "contractBx";
            this.contractBx.Size = new System.Drawing.Size(111, 20);
            this.contractBx.TabIndex = 88;
            // 
            // dobPicker
            // 
            this.dobPicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dobPicker.Location = new System.Drawing.Point(39, 147);
            this.dobPicker.Name = "dobPicker";
            this.dobPicker.Size = new System.Drawing.Size(111, 20);
            this.dobPicker.TabIndex = 78;
            // 
            // msDate
            // 
            this.msDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.msDate.Location = new System.Drawing.Point(39, 186);
            this.msDate.Name = "msDate";
            this.msDate.Size = new System.Drawing.Size(111, 20);
            this.msDate.TabIndex = 80;
            // 
            // lastLbl
            // 
            this.lastLbl.AutoSize = true;
            this.lastLbl.Location = new System.Drawing.Point(36, 53);
            this.lastLbl.Name = "lastLbl";
            this.lastLbl.Size = new System.Drawing.Size(61, 13);
            this.lastLbl.TabIndex = 87;
            this.lastLbl.Text = "Last Name:";
            // 
            // lastBox
            // 
            this.lastBox.Location = new System.Drawing.Point(39, 69);
            this.lastBox.Name = "lastBox";
            this.lastBox.Size = new System.Drawing.Size(111, 20);
            this.lastBox.TabIndex = 75;
            // 
            // majorLbl
            // 
            this.majorLbl.AutoSize = true;
            this.majorLbl.Location = new System.Drawing.Point(36, 248);
            this.majorLbl.Name = "majorLbl";
            this.majorLbl.Size = new System.Drawing.Size(36, 13);
            this.majorLbl.TabIndex = 86;
            this.majorLbl.Text = "Major:";
            // 
            // majorBox
            // 
            this.majorBox.Location = new System.Drawing.Point(39, 264);
            this.majorBox.Name = "majorBox";
            this.majorBox.Size = new System.Drawing.Size(111, 20);
            this.majorBox.TabIndex = 83;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(36, 209);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 85;
            this.label5.Text = "MS Level:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // msBox
            // 
            this.msBox.Location = new System.Drawing.Point(39, 225);
            this.msBox.Name = "msBox";
            this.msBox.Size = new System.Drawing.Size(111, 20);
            this.msBox.TabIndex = 82;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(36, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 13);
            this.label4.TabIndex = 84;
            this.label4.Text = "Mission Set Projection:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(36, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 13);
            this.label3.TabIndex = 81;
            this.label3.Text = "Date Of Birth:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(36, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 79;
            this.label2.Text = "EagleID:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // IDBox
            // 
            this.IDBox.Location = new System.Drawing.Point(39, 108);
            this.IDBox.Name = "IDBox";
            this.IDBox.Size = new System.Drawing.Size(111, 20);
            this.IDBox.TabIndex = 77;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 76;
            this.label1.Text = "First Name:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // firstBox
            // 
            this.firstBox.Location = new System.Drawing.Point(39, 30);
            this.firstBox.Name = "firstBox";
            this.firstBox.Size = new System.Drawing.Size(111, 20);
            this.firstBox.TabIndex = 74;
            // 
            // ptDateBx
            // 
            this.ptDateBx.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.ptDateBx.Location = new System.Drawing.Point(39, 380);
            this.ptDateBx.Name = "ptDateBx";
            this.ptDateBx.Size = new System.Drawing.Size(111, 20);
            this.ptDateBx.TabIndex = 112;
            // 
            // editBtn
            // 
            this.editBtn.Location = new System.Drawing.Point(257, 381);
            this.editBtn.Name = "editBtn";
            this.editBtn.Size = new System.Drawing.Size(108, 23);
            this.editBtn.TabIndex = 113;
            this.editBtn.Text = "Submit Changes";
            this.editBtn.UseVisualStyleBackColor = true;
            // 
            // CadetTab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.editBtn);
            this.Controls.Add(this.ptDateBx);
            this.Controls.Add(this.nurseBox);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.enrollBx);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.dodBx);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.minorBx);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.gradBx);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.g2gBx);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.smpBx);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.termBx);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.cumilitiveBx);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.ptScoreBx);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.contractBx);
            this.Controls.Add(this.dobPicker);
            this.Controls.Add(this.msDate);
            this.Controls.Add(this.lastLbl);
            this.Controls.Add(this.lastBox);
            this.Controls.Add(this.majorLbl);
            this.Controls.Add(this.majorBox);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.msBox);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.IDBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.firstBox);
            this.Controls.Add(this.studentImage);
            this.Name = "CadetTab";
            this.Size = new System.Drawing.Size(916, 481);
            ((System.ComponentModel.ISupportInitialize)(this.studentImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox studentImage;
        private System.Windows.Forms.ComboBox nurseBox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox enrollBx;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox dodBx;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox minorBx;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox gradBx;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox g2gBx;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox smpBx;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox termBx;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox cumilitiveBx;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox ptScoreBx;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox contractBx;
        private System.Windows.Forms.DateTimePicker dobPicker;
        private System.Windows.Forms.DateTimePicker msDate;
        private System.Windows.Forms.Label lastLbl;
        private System.Windows.Forms.TextBox lastBox;
        private System.Windows.Forms.Label majorLbl;
        private System.Windows.Forms.TextBox majorBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox msBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox IDBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox firstBox;
        private System.Windows.Forms.DateTimePicker ptDateBx;
        private System.Windows.Forms.Button editBtn;
    }
}
